Metadata for file: SPS1_Acid_Alkaline_Gases.csv
The acid/alkaline gas sampler drew air through a 3 stage 47mm filter pack at an ambient flow rate of 10 l min-1. The 1st stage of the 3 stage filter pack contained a Teflon filter to remove particles from the air stream, the 2nd stage contained a sodium hydroxide coated quartz filter to trap acidic gases and the final stage contained a citric acid coated quartz filter to trap alkaline gases.
The filters were then extracted in deionised water and analysed by Ion Chromatography.

Contact person: Paul Selleck paul.w.selleck@csiro.au or Melita Keywood melita.keywood@csiro.au
