Metadata for file: SPS1_HiVol_Chem.csv

The file contains particle concentration results for samples taken during SPS1. 

An Ecotech 3000 high volume sampler with a PM2.5 size-selective inlet was used in both SPS1 and SPS2. The ambient flow rate through the inlet was 67.8 m3 hr-1 and was controlled with a mass flow controller. Samples were collected on 250 mm x 200 mm Pall tissuquartz filters (prebaked at 600�C for 4 hours to minimize for adsorbed organic vapours). The filters were stored in sealed containers within a freezer before and after the sampling. 

HiVol filter was analysed for major water soluble ions by suppressed ion chromatography (IC) and for anhydrous sugars including levoglucosan by high-performance anion-exchange chromatography with pulsed amperometric detection (HPAEC-PAD). 

Elemental carbon (EC) and organic carbon (OC) analysis was performed on the PM2.5 HiVol filters using a DRI Model 2001A Thermal-Optical Carbon Analyzer following the IMPROVE-A temperature protocol (Chow et al., 2007). 

The sample concentrations have been blank corrected and the method detection limits determined by the standard variation in the blanks. Concentrations are reported at ambient conditions and local time (UTC+10). 

Contact person: Paul Selleck paul.w.selleck@csiro.au or Melita Keywood melita.keywood@csiro.au