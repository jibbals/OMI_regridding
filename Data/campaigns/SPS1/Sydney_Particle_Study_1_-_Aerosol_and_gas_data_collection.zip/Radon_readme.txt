
Outline
-------

These files contain radon measurements made during SPS1 and SPS2.  They are
intended to cover the following two periods:

Period 1:  05 Feb 2011 - 07 Mar 2011 (Sydney Particle Study, phase 1)
Period 2:  16 Apr 2012 - 14 May 2012 (Sydney Particle Study, phase 2)

Measurements were made using a 700 L dual flow loop, two filter radon detector.
Sampling was conducted 2m agl at a flow rate of approx 40 L/min.
The detector was calibrated prior to deployment (and onsite) using a 118.19 kBq
passive Ra source.
Measurements are reported in local time (UTC+10)

Any questions regarding this dataset should be addressed to either:

Scott Chambers
szc@ansto.gov.au  (02) 9717 3058

or

Alan Griffiths
Alan.Griffiths@ansto.gov.au  (02) 9717 9360


Concentrations have NOT been STP corrected. Internal detector temperature and
pressure data are reported.

Measurements are provided at hourly and half-hourly resolution.  The half-hourly
resolution data have been processed to correct for the relatively slow
response time of the detector (a one-half rise time of about 45 minutes). The
deconvolved radon measurements are also included at hourly resolution, but
do not have a large impact on the reported concentrations.



Included files
--------------

`westmead_radon_sps1_60_min.csv` -- SPS1, hourly data
`westmead_radon_sps2_60_min.csv` -- SPS2, hourly data
`westmead_radon_sps1_30_min.csv` -- SPS1, half-hourly data
`westmead_radon_sps2_30_min.csv` -- SPS2, half-hourly data

Data columns
------------

`rn` -   radon concentration, Bq/m3, hourly files only
         `rn` is derived from the detector output by (1) scaling the raw counts
         by the detector sensitivity and subtracting instrumental background and
         (2) de-lagging the output by 45min. `rn` is nominally the hourly
         average radon concentration between T and T+1

`airt` - air temperature inside the detector, degC

`relhum` - relative humidity inside the detector, %

`press` - air pressure inside the detector, hPa

`rn_deconv` - radon concentration corrected for instrument response, Bq/m3
              `rn_deconv` is the best estimate of the radon concentration
              **at the report time**

`rn_deconv_error` - one-sigma error in `rn_deconv`

`scintillation_counts` - raw counts, total per interval, half-hourly files only
                        The `scintillation_counts` column is included so that
                        these radon measurements can be traced back to the
                        data files archived at ANSTO

