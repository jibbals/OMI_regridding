Aerosol size distributions were measured with two instruments:
1)  a custom-made Scanning Mobility Particle Sizer (SMPS) consisting of a long Differential Mobility Analyser (DMA, TSI 3071A) column and CPC (TSI 3010) (Long-SMPS)
2) and a custom-made nano-SMPS consisting of a short DMA (TSI 3085) column and CPC (TSI 3776) (Nano-SPMS).
The Long-SMPS measured the aerosol size distribution of particles in the range 15 to 736 nm, while the Nano-SMPS measured the aerosol size distribution of particles in the range of 4.6 to 156 nm. 
Size distributions were measured over 5 minute intervals.
Both the Long -SMPS and Nano-SMPS were run with aerosol flows of 0.30 � 0.03 L min-1 and sheath flows of 3.0 � 0.3 L min-1. 
Sizing accuracy of the both  SMPS systems was checked using PolyStyrene Latex (PSL) solution with errors being less than 2 %.
Merging of the Long-SMPS and Nano-SMPS data sets to produce a distribution between 4.6 nm to 7376 nm 
The counting efficiency of the Nano-SMPS was determined by comparing the total number concentration of particles greater than 10 nm with the particle number concentration measured using the CPC TSI3772 and a scaling factor determined.  The Nano-SMPS was then scaled to the scaling factor.
The two systems have an overlap between 15 and 156 nm.  The relationship between the concentrations measured in the overlapping size ranges were used to scale the Long-SMPS concentrations to the Nano-SMPS concentrations. 
Diameter units are nm
Concentrations units dN/dLogdp particles cm-3 

Contact person: Melita Keywood melita.keywood@csiro.au