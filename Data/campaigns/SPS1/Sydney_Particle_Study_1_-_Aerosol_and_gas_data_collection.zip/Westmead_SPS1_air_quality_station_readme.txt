Parameter	Instrument Model	Method	Date
Nephelometer	Ecotech 1000G 10-0325	AS/NZS 3580.12.1:2001	February to March 2011
Sulphur Dioxide	Ecotech EC9850 08-0100	AS 3580.4.1-2008	February to March 2011
PM10	Thermo TEOM1405 1405A211581011	AS 3580.9.8-2008	February to March 2011
Ozone	Ecotech EC9810 07-0614	AS 3580.6.1-2011	February to March 2011
Oxides of Nitrogen	Ecotech EC9841 07-1572	AS 3580.5.1-2011	February to March 2011
Solar	Middleton 8536	AS 3580.14-2011	February to March 2011
Wind speed & wind direction	Met-One MET505 G4056	AS 3580.14-2011	February to March 2011
Temperature & humidity	Vaisala HMP 155	AS 3580.14-2011	February to March 2011
			
			
The Westmead air quality monitoring site was maintained in accordance with Climate and Atmospheric Science Standard of Operation Procedures which includes scheduled site visit and instruments calibration.			

contact person: Yvonne Scorgie Yvonne.Scorgie@environment.nsw.gov.au